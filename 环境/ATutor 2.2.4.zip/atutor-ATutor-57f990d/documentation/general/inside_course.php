<?php require('../common/body_header.inc.php'); $lm = '$LastChangedDate$'; ?>

<h2>Course Features</h2>

<p>After a student has entered into a course, he/she is presented with the course Home page. The Home page may contain a course banner, links to Student Tool, and course announcements. </p>

<p>A few of the course features are explained here, as they may be a little tricky for new users. Other features are fairly straight forward and should be intuitive to use. Look for the handbook link while using a tool, to open its help page directly.</p>

<?php require('../common/body_footer.inc.php'); ?>