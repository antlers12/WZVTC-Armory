<?php
	$_pages = array();
    $_pages['introduction.php']				= 'Introduction';
    $_pages['login.php']					= 'Login';
    $_pages['register.php']					= 'Register';
    $_pages['browse_courses.php']			= 'Browse Courses';
    $_pages['password_reminder.php']		= 'Forgot Your Password';
    $_pages['my_start_page.php']			= 'My Start Page';
    $_pages['my_courses.php']				= 'My Courses';
    $_pages['create_course.php']			= 'Create Courses';
    $_pages['profile.php']					= 'Profile';
    $_pages['preferences.php']				= 'Preferences';
    $_pages['inbox.php']					= 'Inbox';
	$_pages['inside_course.php']			= 'Inside a Course';
	$_pages['export_content.php']			= 'Export Content';
	$_pages['packages.php']					= 'Packages';
	$_pages['tile.php']						= 'TILE Repository Search';
	$_pages['file_storage.php']				= 'File Storage';
	$_pages['fs_new_file.php']				= 'New/Edit File';
    $_pages['my_network.php']				= 'My Networking';
    $_pages['my_contacts.php']				= 'My Contacts';
    $_pages['my_groups.php']				= 'Network Groups';
    $_pages['my_profile.php']				= 'Network Profile';
    $_pages['my_gadgets.php']				= 'Gadgets';
    $_pages['my_settings.php']				= 'Social Settings';
	$_pages['pa_index.php']					= 'Photo Gallery';
	$_pages['pa_albums.php']				= 'Albums';
	$_pages['pa_photo.php']					= 'Photo';
	$_pages['pa_comments.php']				= 'Comments';
	$_pages['assignment_dropbox.php']				= 'Assignment Dropbox';

?>