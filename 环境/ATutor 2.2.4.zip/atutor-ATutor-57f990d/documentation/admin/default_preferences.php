<?php require('../common/body_header.inc.php'); $lm = '$LastChangedDate$'; ?>

<h2>Default Preferences</h2>

<p>The default preferences are applied to newly created accounts at the time of their creation, and to guests when accessing public courses.  Members may alter their settings once they have logged in by going to the Preferences area in the main navigation. For more information, see <a href="../general/preferences.php">Preferences</a> in the general help area.</p>

<?php require('../common/body_footer.inc.php'); ?>