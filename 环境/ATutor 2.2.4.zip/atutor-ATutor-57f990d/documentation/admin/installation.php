<?php require('../common/body_header.inc.php'); $lm = '$LastChangedDate$'; ?>

<h2>Installation</h2>
	<p>This section describes the requirements and important considerations needed for running ATutor. It also details the steps involved in installing and upgrading an installation.</p>

<?php require('../common/body_footer.inc.php'); ?>
