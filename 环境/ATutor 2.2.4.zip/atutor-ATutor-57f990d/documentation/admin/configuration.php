<?php require('../common/body_header.inc.php'); $lm = '$LastChangedDate$'; ?>

<h2>Administrator Home</h2>
	<p>The Administrator Home page is the first screen after logging in. It displays a linked list of the administrative tools, shows new and pending <a href="instructor_requests.php">Instructor Requests</a>, provides the ability to check for the latest version of ATutor by connecting to the atutor.ca website, and basic installation statistics and information.</p>

<?php require('../common/body_footer.inc.php'); ?>