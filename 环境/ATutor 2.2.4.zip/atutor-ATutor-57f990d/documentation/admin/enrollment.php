<?php require('../common/body_header.inc.php'); $lm = '$LastChangedDate: 2006-06-29 11:25:07 -0400 (Thu, 29 Jun 2006) $'; ?>

	<h2>Enrollment</h2>
	<p>The Enrollment list for a particular course determines which of your students have access to the course content and course management tools. Instructors can create, import and export student lists. </p>
	
	<p>To administer members of a course, select the <em>Enrollment</em> tab, then select a course and press the <em>Filter</em> button.</p>

<?php require('../common/body_footer.inc.php'); ?>
