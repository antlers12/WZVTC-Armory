<?php require('../common/body_header.inc.php'); $lm = '$LastChangedDate: 2006-06-29 11:25:07 -0400 (Thu, 29 Jun 2006) $'; ?>

<h2>Export Forums</h2>

<p>This utility can be used to take a static copy of a course forum as a standalone archive of messages contained in the forum exported. An exported forum might be uploaded into the File Manager, unzipped there,  and linked from a content page in ATutor to make past discussions available to current students. Or, an exported forum might be uploaded to an external Web site to make it available as an archive outside of ATutor. </p>

<?php require('../common/body_footer.inc.php'); ?>
