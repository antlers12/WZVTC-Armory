<?php require('../common/body_header.inc.php'); $lm = '$LastChangedDate: 2006-06-29 11:25:07 -0400 (Thu, 29 Jun 2006) $'; ?>

<h2>Create/Edit Content Folders</h2>

	<p> A folder can be created to group related content. A <strong>release date</strong> can be set to automatically make content in the folder available to students at a certain date and time. <strong>Prerequisite test(s)</strong> can be set from those available in course, to grant access based on taking or passing a test. Tests are first setup using the <a href="tests_surveys.php">Tests and Surveys Manager</a>.</p>:

	
<?php require('../common/body_footer.inc.php'); ?>