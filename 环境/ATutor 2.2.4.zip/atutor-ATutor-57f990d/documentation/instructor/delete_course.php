<?php require('../common/body_header.inc.php'); $lm = '$LastChangedDate$'; ?>

<h2>Delete Course</h2>
	<p>An instructor can delete a course using the <a href="properties.php">Properties</a> manager. Once a course has been deleted from the system, it can not be restored (unless there is a <a href="backups.php">backup</a>). There will be prompts to confirm the action before actual deletion occurs.</p>

<?php require('../common/body_footer.inc.php'); ?>