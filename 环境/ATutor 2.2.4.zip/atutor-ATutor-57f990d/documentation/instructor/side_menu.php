<?php require('../common/body_header.inc.php'); $lm = '$LastChangedDate$'; ?>

<h2>Side Menu</h2>
	<p>Some of the course tools can be accessed through the side menu. Which side menu boxes, and the order in which they will appear, can be controlled by selecting the tool name from the dropdowns, and arrange them in order of preference. Those more likely to be used can be placed at the top of the menu. To remove a menu box, choose the blank option from the selection menus in the side menu editor</p>

<?php require('../common/body_footer.inc.php'); ?>