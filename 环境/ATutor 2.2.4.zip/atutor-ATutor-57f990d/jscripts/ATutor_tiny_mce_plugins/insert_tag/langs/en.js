tinyMCE.addI18n('en.insert_tag',{
	termdesc : 'Insert term tag',
	codedesc : 'Insert code tag',
	mediadesc : 'Insert media tag',
	texdesc : 'Insert tex tag'
});